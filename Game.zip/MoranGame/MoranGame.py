from tkinter import *
from PIL import Image, ImageTk
import random

#detects collision of lion and player
def collisionDetector():
    lb = canvas.bbox(lion)
    pb = canvas.bbox(player)
    if lb[0] < pb[2] < lb[2] and lb[1] < pb[1] < lb[3]:
        canvas.delete(player)
        canvas.delete(lion)
        winner.place(x=50, y=50)
        moran = canvas.create_image((300, 100), anchor=NW, image=win_image)
    elif lb[0] < pb [0] < lb[2] and lb[1] < pb[1] < lb[3]:
        canvas.delete(player)
        canvas.delete(lion)
        winner.place(x=50, y=50)
        moran = canvas.create_image((300, 100), anchor=NW, image=win_image)
    elif pb[0] < lb[0] < pb[2] and pb[1] < lb[1] < pb[3]:
        canvas.delete(player)
        canvas.delete(lion)
        winner.place(x=50, y=50)
        moran = canvas.create_image((300, 100), anchor=NW, image=win_image)
    elif lb[0] < pb[0] < lb[2] and lb[1] < pb[3] < lb[3]:
        canvas.delete(player)
        canvas.delete(lion)
        winner.place(x=50, y=50)
        moran = canvas.create_image((300, 100), anchor=NW, image=win_image)

# lion bbox to keep it on canvas

def playerEdgeReached():
    playerBound = canvas.bbox(player) #list of x y min and max of boundary for image
    playerleft = playerBound[0]
    playerright = playerBound[2]
    playertop = playerBound[1]
    playerbottom = playerBound[3]
    if playerleft < 0:
        canvas.move(player, 10, 0)
    elif playertop < 0:
        canvas.move(player, 0, 10)
    elif playerright > 1100:
        canvas.move(player, -10, 0)
    elif playerbottom > 700:
        canvas.move(player, 0, -10)



#movement functions for player
def left(e):
    canvas.move(player, -10, 0)
    playerEdgeReached()
    collisionDetector()

def right(e):
    canvas.move(player, 10, 0)
    playerEdgeReached()
    collisionDetector()

def up(e):
    canvas.move(player, 0, -10)
    playerEdgeReached()
    collisionDetector()

def down(e):
    canvas.move(player, 0, 10)
    playerEdgeReached()
    collisionDetector()





win = Tk() #create tkinter frame


canvas = Canvas(win, width=1100, height=700, bg="red") #set up canvas
canvas.pack()
#background
fieldImg = PhotoImage(file='moran_back.png')
fieldBg = canvas.create_image(20,20, anchor=NW, image= fieldImg)


#create random x, y coor to place lion
lionx_coor = random.randint(10, 600)
liony_coor = random.randint(10, 600)
#create random x, y coor to place player
playerx_coor = random.randint(10, 600)
playery_coor = random.randint(10, 600)

win_image = ImageTk.PhotoImage(Image.open("moranWinner.png"))
#adding image to canvas
L_image = ImageTk.PhotoImage(Image.open("lion.png"))
lion = canvas.create_image((lionx_coor,liony_coor), anchor=NW, image=L_image)


P_image = ImageTk.PhotoImage(Image.open("player.png"))
player = canvas.create_image((playerx_coor,playery_coor), image=P_image)

#add you win label
winner = Label(win, text = "You are now a Moran!",
                font=("Arial", 32),
               fg = "Green", bg= "red")


#add keys to movement functions

win.bind_all("<Left>", left)
win.bind_all("<Right>", right)
win.bind_all("<Up>", up)
win.bind_all("<Down>", down)


win.mainloop()